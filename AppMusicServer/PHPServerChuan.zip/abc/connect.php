<?php
	$hostname = "localhost";
	$username = "id3196134_phatdroid94";
	$password = "lovely94";
	$databasename = "id3196134_mp3zing";

	$con = mysqli_connect($hostname,$username,$password,$databasename);
	mysqli_query($con,"SET NAMES 'utf8'");
?>